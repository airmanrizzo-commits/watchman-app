# watchman-app
Vault-triggered scroll AI interface
